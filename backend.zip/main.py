import os
import uuid
import asyncio
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
import yt_dlp
from fastapi.middleware.cors import CORSMiddleware

import time

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class VideoRequest(BaseModel):
    url: str
    format_id: str = "bestvideo+bestaudio/best"
    start_time: str = None
    end_time: str = None

EXPLORE_CACHE = {}
CACHE_TTL = 900  # 15 minutes in seconds

@app.get("/explore")
async def explore_live(category: str = "music"):
    current_time = time.time()
    
    # Check cache
    if category in EXPLORE_CACHE:
        cache_entry = EXPLORE_CACHE[category]
        if current_time - cache_entry['timestamp'] < CACHE_TTL:
            return {"category": category, "streams": cache_entry['data']}
    
    ydl_opts = {
        'extract_flat': 'in_playlist',
        'quiet': True,
        'no_warnings': True,
        'simulate': True,
    }
    
    search_query = f"ytsearch20:live stream {category}"
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(search_query, download=False)
            entries = info.get('entries', [])
            
            streams = []
            for entry in entries:
                if entry:
                    streams.append({
                        "id": entry.get('id'),
                        "title": entry.get('title'),
                        "thumbnail": entry.get('thumbnails', [{}])[-1].get('url', f"https://i.ytimg.com/vi/{entry.get('id')}/hqdefault.jpg"),
                        "channel": entry.get('uploader'),
                        "url": entry.get('url'),
                    })
            
            # Save to cache
            EXPLORE_CACHE[category] = {
                "timestamp": current_time,
                "data": streams
            }
            
            return {"category": category, "streams": streams}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/info")
async def get_info(req: VideoRequest):
    ydl_opts = {
        'cookiefile': os.path.abspath('cookies.txt'),
        'extractor_args': {'youtube': {'player_client': ['android', 'web']}},
        'quiet': True,
        'no_warnings': True,
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(req.url, download=False)
            formats = info.get('formats', [])
            clean_formats = []
            for f in formats:
                if f.get('format_id') and (f.get('height') or f.get('ext') == 'm4a'):
                    res = f"{f.get('height')}p" if f.get('height') else "Audio Only"
                    clean_formats.append({
                        "format_id": f.get('format_id'),
                        "resolution": res,
                        "ext": f.get('ext')
                    })
            return {
                "title": info.get('title'),
                "thumbnail": info.get('thumbnail'),
                "duration": info.get('duration'),
                "is_live": info.get('is_live', False),
                "id": info.get('id'),
                "extractor": info.get('extractor'),
                "formats": clean_formats
            }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/download")
async def download_video(req: VideoRequest):
    out_filename = f"dl_{uuid.uuid4().hex}"
    
    ydl_opts = {
        'cookiefile': os.path.abspath('cookies.txt'),
        'extractor_args': {'youtube': {'player_client': ['android', 'web']}},
        'format': req.format_id if req.format_id else 'bestvideo+bestaudio/best',
        'outtmpl': f'{out_filename}.%(ext)s',
        'merge_output_format': 'mp4',
        'quiet': True,
    }
    
    if req.start_time and req.end_time:
        ydl_opts['download_ranges'] = yt_dlp.utils.download_range_func(None, [(yt_dlp.utils.parse_duration(req.start_time), yt_dlp.utils.parse_duration(req.end_time))])
        ydl_opts['force_keyframes_at_cuts'] = True

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(req.url, download=True)
            filename = ydl.prepare_filename(info)
            if not os.path.exists(filename):
                filename = f"{out_filename}.mp4"
            
            return FileResponse(filename, media_type='application/octet-stream', filename=os.path.basename(filename))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
